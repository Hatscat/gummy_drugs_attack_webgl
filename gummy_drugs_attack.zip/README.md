Concept : Chassez et mangez des champignons hallucinog�nes dans ce shooter n�o-minimaliste�!

Auteurs : Lucien Boudy & Maxime Lo Re.

Contr�les : FPS en azerty classique ("zqsd" pour le d�placement, "espace" pour sauter et "clic gauche" pour le tir) + "f" pour consommer une pilule � port�e. Le "wall jump" est possible, et le tir peut �tre maintenu.

Bugs connus et non-corrig�s�: aucun.

En plus�: un mode "d�veloppeur" est activable en ajoutant "?" � la fin de l'URL du jeu, il permet d'�tre invincible, de consommer de la drogue avec la touche "&", de visualiser la map g�n�r�e sous forme d'image et de voir au del� du fog.
