"use strict"

function draw () {
	window.scene.render();
}
